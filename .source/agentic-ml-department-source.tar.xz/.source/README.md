# Reproducible source snapshot

`agentic-ml-department-source.tar.xz` is a checksum-verified snapshot of the complete project source tree. It is retained for reproducible bootstrap/transport. It is not an installer and not the only place where the code is stored.

The GitHub Actions workflow `.github/workflows/publish-source.yml` automatically expands this snapshot after an archive update and commits the source into normal, browsable paths such as `src/`, `dashboard/`, `tests/`, `scripts/`, and `docs/`. The published repository is therefore intended to contain both the archive and the full source tree.
